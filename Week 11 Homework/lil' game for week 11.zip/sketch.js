var x = 100;
var y =  80;

var mousex = 0;
var mousey = 0;

var sqr1x = 250
var sqr1y = 80

var sqr2x = 325
var sqr2y = 636

var shape1Speed
var shape2Speed

function setup() {
  createCanvas(800, 800);
  frameRate(10);
  //background(240);
}

function draw() {
  background(60,00,160);
  fill(255, 60, 100);
  text("(" + mouseX + ", " + mouseY + ")", mouseX, mouseY);
  stroke(0);
  //player 
  circle(x, y, 50);
  
//move player circle
  if (keyIsDown(83))
    {
      y += 15
    }
  else if (keyIsDown(87))
    {
      y -= 15
    }
  
   if (keyIsDown(65))
    {
      x -= 15
    }
  else if (keyIsDown(68))
    {
      x += 15
    }
  
   //obstacles
  fill(91, 200, 40)
  ellipse(209, 441, 80, 150);
  ellipse(557, 117, 150, 80);
  
  //escape
  rect(755, 755, 50, 80);
  textSize(28);
  text('Escape!', 694, 737);
  
  //check for exit
  if(x > width && y > width)
    {
      fill(0);
 
      textSize(26);
      text("You Win!", width/2-80, height/2-80);
    }
  
  
  //shape speed for moving sqrs
    shape1Speed = Math.floor(Math.floor(Math.random() * 15) + 1);
    shape2Speed = Math.floor(Math.floor(Math.random() * 15) + 1);
 
  
  //moving shapes
  fill(00, 00, 44)
  square(sqr1x, sqr1y, 30)
  square(sqr2x, sqr2y, 30)
  sqr1x += shape1Speed
  sqr1y += shape1Speed
  sqr2x += shape2Speed
  sqr2y += shape2Speed

  //rebound
 if(sqr1x > width)
   {
     sqr1x = 0;
   }
  
  if(sqr1y > height)
    {
      sqr1y = 0;
    }
  
  if(sqr2x > width)
   {
     sqr2x = 0;
   }
  if(sqr2y > height)
    {
      sqr2y = 0;
    }

//color and mouse obstacle
fill(250, 120, 80);
circle(mousex, mousey, 75)

}

//draw shape on mouse press
  function mousePressed()
  {
    mousex = mouseX;
    mousey = mouseY;
  }





